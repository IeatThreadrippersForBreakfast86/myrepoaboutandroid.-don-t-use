package com.ninjatech.lanbridge.proxy;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * Encodes and decodes the in-band binary header used by the LAN Bridge UDP relay.
 *
 * <p>The protocol is identical on both sides (Android relay and Forge mod mixin):
 * <pre>
 *   Offset  Size    Field
 *   0       1       Magic byte: 0x4C ('L' for LanBridge)
 *   1       1       Address type: 0x01 = IPv4 (4 raw bytes), 0x04 = hostname
 *   2       4       IPv4 address (network byte order)                 [type 0x01]
 *     or
 *   2       1       hostname length N                                    [type 0x04]
 *   3..     N       hostname bytes (ASCII/UTF-8)                        [type 0x04]
 *   last    2       Port (network byte order, big-endian)
 *           ...     Original UDP payload
 * </pre>
 *
 * <p>The Forge mod's {@code DatagramSocketMixin} prepends this header to every
 * outbound datagram destined for a host that should be routed through the relay,
 * rewriting the datagram's target address to the relay's {@code (lanHost, udpRelayPort)}.
 * The Android {@code UdpRelayEngine} strips the header, forwards the payload to the
 * real destination, and &mdash; on return &mdash; prepends a source header so the
 * mod can restore the real source address.</p>
 *
 * <p>This class is thread-safe (all methods are pure / operate on local buffers).</p>
 */
public final class LanBridgeUdpFramer {

    private LanBridgeUdpFramer() {}

    /** Magic byte that identifies a LanBridge-framed datagram. */
    public static final byte MAGIC = 0x4C;

    /** Address type: 4 raw IPv4 bytes follow. */
    public static final byte ADDR_TYPE_IPV4 = 0x01;

    /** Address type: a 1-byte length + hostname bytes follow. */
    public static final byte ADDR_TYPE_HOSTNAME = 0x04;

    /**
     * Result of parsing a framed datagram: the real destination/source address
     * and the offset where the original UDP payload begins.
     */
    public static final class ParsedHeader {
        public final InetSocketAddress address;
        public final int payloadOffset;
        public final int payloadLength;

        ParsedHeader(InetSocketAddress address, int payloadOffset, int payloadLength) {
            this.address = address;
            this.payloadOffset = payloadOffset;
            this.payloadLength = payloadLength;
        }
    }

    /**
     * Build the framed datagram: {@code [header][originalPayload]}.
     *
     * @param dest     the real destination address (host + port) that the relay
     *                 should forward to.
     * @param payload  the original UDP payload bytes.
     * @param offset   offset within {@code payload} where the data starts.
     * @param length   number of bytes of data.
     * @return a new byte array containing the framed datagram.
     */
    public static byte[] frame(InetSocketAddress dest, byte[] payload, int offset, int length) {
        String host = dest.getHostString();
        int port = dest.getPort();
        byte[] header = buildHeader(host, port, dest.getAddress());
        byte[] out = new byte[header.length + length];
        System.arraycopy(header, 0, out, 0, header.length);
        System.arraycopy(payload, offset, out, header.length, length);
        return out;
    }

    /**
     * Build just the header bytes for the given host + port.
     *
     * <p>If {@code resolved} is a raw IPv4 address we use the compact 4-byte
     * encoding (type 0x01). Otherwise we encode the hostname string (type 0x04),
     * which lets the relay resolve it itself &mdash; important for STUN/TURN
     * hostnames like {@code na.stun.essential.gg}.</p>
     */
    private static byte[] buildHeader(String host, int port, InetAddress resolved) {
        // Prefer raw IPv4 when we have it (avoids a DNS round-trip on the relay).
        if (resolved != null && resolved.getAddress().length == 4) {
            byte[] ip = resolved.getAddress();
            ByteBuffer buf = ByteBuffer.allocate(1 + 1 + 4 + 2);
            buf.put(MAGIC);
            buf.put(ADDR_TYPE_IPV4);
            buf.put(ip);
            buf.putShort((short) (port & 0xFFFF));
            return buf.array();
        }
        // Otherwise encode the hostname string.
        byte[] hostBytes = host.getBytes(StandardCharsets.UTF_8);
        if (hostBytes.length > 255) {
            throw new IllegalArgumentException("Hostname too long for UDP relay header: " + host);
        }
        ByteBuffer buf = ByteBuffer.allocate(1 + 1 + 1 + hostBytes.length + 2);
        buf.put(MAGIC);
        buf.put(ADDR_TYPE_HOSTNAME);
        buf.put((byte) hostBytes.length);
        buf.put(hostBytes);
        buf.putShort((short) (port & 0xFFFF));
        return buf.array();
    }

    /**
     * Parse a framed datagram, extracting the embedded address and locating the
     * original payload.
     *
     * @param data    the received datagram buffer.
     * @param offset  start offset of the data.
     * @param length  total length of the data.
     * @return the parsed header, or {@code null} if the data does not start with
     *         the magic byte or is too short / malformed.
     */
    public static ParsedHeader parse(byte[] data, int offset, int length) {
        if (length < 4) return null; // magic + type + at least 1 addr byte + 0 port
        if (data[offset] != MAGIC) return null;

        int pos = offset + 1;
        byte addrType = data[pos++];

        String host;
        switch (addrType) {
            case ADDR_TYPE_IPV4: {
                if (length < 1 + 1 + 4 + 2) return null;
                byte[] ip = new byte[4];
                System.arraycopy(data, pos, ip, 0, 4);
                pos += 4;
                try {
                    host = InetAddress.getByAddress(ip).getHostAddress();
                } catch (UnknownHostException e) {
                    return null;
                }
                break;
            }
            case ADDR_TYPE_HOSTNAME: {
                int hostLen = data[pos++] & 0xFF;
                if (length < (pos - offset) + hostLen + 2) return null;
                host = new String(data, pos, hostLen, StandardCharsets.UTF_8);
                pos += hostLen;
                break;
            }
            default:
                return null;
        }

        if (length < (pos - offset) + 2) return null;
        int port = ((data[pos] & 0xFF) << 8) | (data[pos + 1] & 0xFF);
        pos += 2;

        int payloadOffset = pos;
        int payloadLength = length - (pos - offset);
        if (payloadLength < 0) return null;

        InetSocketAddress addr = new InetSocketAddress(host, port);
        return new ParsedHeader(addr, payloadOffset, payloadLength);
    }

    /**
     * Quick check: does this buffer start with the LanBridge magic byte?
     * Used by the mixin's receive() path to decide whether to strip a header.
     */
    public static boolean isFramed(byte[] data, int offset, int length) {
        return length >= 4 && data[offset] == MAGIC;
    }
}
