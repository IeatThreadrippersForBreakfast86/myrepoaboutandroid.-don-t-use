package com.ninjatech.lanbridge.ui;

import com.ninjatech.lanbridge.config.LanBridgeConfig;
import com.ninjatech.lanbridge.proxy.LanBridgeDiscovery;
import com.ninjatech.lanbridge.proxy.LanBridgeProxyInstaller;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.ConfigScreenHandler;

import java.util.concurrent.TimeUnit;

/**
 * Forge in-game config screen for the LAN Bridge mod, exposed via Forge's
 * {@link ConfigScreenHandler} / {@code IConfigScreenFactory} so the Mods list
 * "Config" button opens it.
 *
 * <p>Uses the Mojmap-named Minecraft widgets (the Forge 1.20.1 MDK ships against
 * Mojmap names). Lets the user set the bridge host IP, proxy port, game relay port,
 * connect timeout, and toggles for auth-only routing, auto-discovery, and fallback,
 * plus a "Discover now" button and an "Apply & (re)install" button.</p>
 */
public class LanBridgeConfigScreen extends Screen {

    private final Screen parent;
    private EditBox hostField;
    private EditBox proxyPortField;
    private EditBox gameRelayField;
    private EditBox udpRelayField;
    private EditBox timeoutField;
    private Button authOnlyBtn;
    private Button autoDiscoverBtn;
    private Button allowFallbackBtn;
    private Button routeEssentialBtn;
    private Button discoverBtn;
    private Button applyBtn;
    private Button doneBtn;
    private String statusMsg = "";

    public LanBridgeConfigScreen(Screen parent) {
        super(Component.literal("LAN Bridge Configuration"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        LanBridgeConfig cfg = LanBridgeConfig.get();
        Minecraft mc = Minecraft.getInstance();
        int cx = this.width / 2;
        int y = 40;

        hostField = new EditBox(mc.font, cx - 160, y, 320, 20, Component.literal("Host IP"));
        hostField.setMaxLength(64);
        hostField.setValue(cfg.getBridgeHostIp());
        hostField.setHint(Component.literal("e.g. 192.168.1.50"));
        addWidget(hostField);
        y += 30;

        proxyPortField = new EditBox(mc.font, cx - 160, y, 320, 20, Component.literal("Proxy port"));
        proxyPortField.setMaxLength(5);
        proxyPortField.setValue(Integer.toString(cfg.getProxyPort()));
        addWidget(proxyPortField);
        y += 30;

        gameRelayField = new EditBox(mc.font, cx - 160, y, 320, 20, Component.literal("Game relay port"));
        gameRelayField.setMaxLength(5);
        gameRelayField.setValue(Integer.toString(cfg.getGameRelayPort()));
        addWidget(gameRelayField);
        y += 30;

        udpRelayField = new EditBox(mc.font, cx - 160, y, 320, 20, Component.literal("UDP relay port"));
        udpRelayField.setMaxLength(5);
        udpRelayField.setValue(Integer.toString(cfg.getUdpRelayPort()));
        udpRelayField.setHint(Component.literal("0 = disabled (Essential P2P)"));
        addWidget(udpRelayField);
        y += 30;

        timeoutField = new EditBox(mc.font, cx - 160, y, 320, 20, Component.literal("Connect timeout (ms)"));
        timeoutField.setMaxLength(6);
        timeoutField.setValue(Integer.toString(cfg.getConnectTimeoutMs()));
        addWidget(timeoutField);
        y += 30;

        authOnlyBtn = Button.builder(Component.literal(authOnlyLabel(cfg.isAuthOnly())),
                b -> { cfg.setAuthOnly(!cfg.isAuthOnly()); b.setMessage(Component.literal(authOnlyLabel(cfg.isAuthOnly()))); })
                .bounds(cx - 160, y, 320, 20).build();
        addRenderableWidget(authOnlyBtn);
        y += 24;

        autoDiscoverBtn = Button.builder(Component.literal("Auto-discover: " + cfg.isAutoDiscover()),
                b -> { cfg.setAutoDiscover(!cfg.isAutoDiscover()); b.setMessage(Component.literal("Auto-discover: " + cfg.isAutoDiscover())); })
                .bounds(cx - 160, y, 320, 20).build();
        addRenderableWidget(autoDiscoverBtn);
        y += 24;

        allowFallbackBtn = Button.builder(Component.literal("Allow fallback to direct: " + cfg.isAllowFallback()),
                b -> { cfg.setAllowFallback(!cfg.isAllowFallback()); b.setMessage(Component.literal("Allow fallback to direct: " + cfg.isAllowFallback())); })
                .bounds(cx - 160, y, 320, 20).build();
        addRenderableWidget(allowFallbackBtn);
        y += 24;

        routeEssentialBtn = Button.builder(Component.literal(routeEssentialLabel(cfg.isRouteEssential())),
                b -> { cfg.setRouteEssential(!cfg.isRouteEssential()); b.setMessage(Component.literal(routeEssentialLabel(cfg.isRouteEssential()))); })
                .bounds(cx - 160, y, 320, 20).build();
        addRenderableWidget(routeEssentialBtn);
        y += 28;

        discoverBtn = Button.builder(Component.literal("Discover now"), b -> runDiscovery())
                .bounds(cx - 160, y, 150, 20).build();
        addRenderableWidget(discoverBtn);

        applyBtn = Button.builder(Component.literal("Apply & (re)install"), b -> apply())
                .bounds(cx + 10, y, 150, 20).build();
        addRenderableWidget(applyBtn);
        y += 28;

        doneBtn = Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 80, y, 160, 20).build();
        addRenderableWidget(doneBtn);
    }

    /** Human-readable label for the auth-only toggle, explaining what each mode does. */
    private static String authOnlyLabel(boolean authOnly) {
        return authOnly
                ? "Route: AUTH hosts only"
                : "Route: ALL network traffic";
    }

    /** Human-readable label for the Essential UDP routing toggle. */
    private static String routeEssentialLabel(boolean routeEssential) {
        return routeEssential
                ? "Essential P2P (UDP): ENABLED"
                : "Essential P2P (UDP): disabled";
    }

    private void apply() {
        LanBridgeConfig cfg = LanBridgeConfig.get();
        cfg.setBridgeHostIp(hostField.getValue());
        try { cfg.setProxyPort(Integer.parseInt(proxyPortField.getValue().trim())); } catch (Exception e) { cfg.setProxyPort(LanBridgeConfig.DEFAULT_PROXY_PORT); }
        try { cfg.setGameRelayPort(Integer.parseInt(gameRelayField.getValue().trim())); } catch (Exception e) { cfg.setGameRelayPort(LanBridgeConfig.DEFAULT_GAME_RELAY_PORT); }
        try { cfg.setUdpRelayPort(Integer.parseInt(udpRelayField.getValue().trim())); } catch (Exception e) { cfg.setUdpRelayPort(LanBridgeConfig.DEFAULT_UDP_RELAY_PORT); }
        try { cfg.setConnectTimeoutMs(Integer.parseInt(timeoutField.getValue().trim())); } catch (Exception e) { cfg.setConnectTimeoutMs(4000); }
        cfg.save();
        if (cfg.hasHost()) {
            LanBridgeProxyInstaller.install(null);
            statusMsg = "\u00a7eApplied and installed proxy \u2192 " + cfg.getBridgeHostIp() + ":" + cfg.getProxyPort();
        } else {
            LanBridgeProxyInstaller.uninstall();
            statusMsg = "\u00a7eSaved. Host IP is empty; proxy not installed.";
        }
    }

    private void runDiscovery() {
        statusMsg = "\u00a7eScanning the LAN...";
        Thread t = new Thread(() -> {
            try {
                LanBridgeDiscovery.BridgeInfo info = LanBridgeDiscovery.discover(10, TimeUnit.SECONDS);
                if (info == null) {
                    statusMsg = "\u00a7cNo bridge found on the LAN.";
                    return;
                }
                LanBridgeConfig cfg = LanBridgeConfig.get();
                cfg.setBridgeHostIp(info.lanHost);
                cfg.setProxyPort(info.proxyPort);
                cfg.setGameRelayPort(info.gameRelayPort);
                cfg.setUdpRelayPort(info.udpRelayPort);
                cfg.save();
                LanBridgeProxyInstaller.install(null);
                statusMsg = "\u00a7aFound bridge \u2192 " + info.lanHost + ":" + info.proxyPort;
                Minecraft.getInstance().execute(() -> {
                    if (hostField != null) hostField.setValue(info.lanHost);
                    if (proxyPortField != null) proxyPortField.setValue(Integer.toString(info.proxyPort));
                    if (gameRelayField != null) gameRelayField.setValue(Integer.toString(info.gameRelayPort));
                    if (udpRelayField != null) udpRelayField.setValue(Integer.toString(info.udpRelayPort));
                });
            } catch (Exception e) {
                statusMsg = "\u00a7cDiscovery failed: " + e.getMessage();
            }
        }, "lanbridge-discovery-ui");
        t.setDaemon(true);
        t.start();
    }

    @Override
    public void render(GuiGraphics gui, int mouseX, int mouseY, float partialTick) {
        renderBackground(gui);
        super.render(gui, mouseX, mouseY, partialTick);
        gui.drawCenteredString(this.font, this.title, this.width / 2, 16, 0xFFFFFF);
        hostField.render(gui, mouseX, mouseY, partialTick);
        proxyPortField.render(gui, mouseX, mouseY, partialTick);
        gameRelayField.render(gui, mouseX, mouseY, partialTick);
        udpRelayField.render(gui, mouseX, mouseY, partialTick);
        timeoutField.render(gui, mouseX, mouseY, partialTick);
        if (!statusMsg.isEmpty()) {
            gui.drawCenteredString(this.font, statusMsg, this.width / 2, this.height - 24, 0xFFFFAA00);
        }
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }

    /**
     * Convenience factory that wraps this screen in Forge's
     * {@link ConfigScreenHandler.ConfigScreenFactory} record. The mod registers the
     * config screen via
     * {@code ModLoadingContext.get().registerExtensionPoint(...)} using a lambda
     * directly, but this helper is kept for callers that prefer an explicit handle.
     */
    public static ConfigScreenHandler.ConfigScreenFactory factory() {
        return new ConfigScreenHandler.ConfigScreenFactory((mc, parent) -> new LanBridgeConfigScreen(parent));
    }
}
