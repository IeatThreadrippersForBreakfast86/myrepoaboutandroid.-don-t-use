package com.ninjatech.lanbridge.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LAN Bridge client configuration.
 *
 * <p>The mod reads a tiny JSON file at {@code config/lanbridge.json} containing the
 * LAN address of the host device (the Android phone running the Minecraft LAN Bridge
 * app) and the proxy port the app exposes (default 25580). With these two values the
 * mod routes every Minecraft authentication / session / profile HTTPS request through
 * the host device's CONNECT-tunnel proxy instead of the PC reaching the internet
 * directly.</p>
 *
 * <p>If {@code bridgeHostIp} is left blank the mod will attempt auto-discovery by
 * probing the {@code /__lanbridge_info} endpoint on likely host IPs. This keeps the
 * "no new IP address" guarantee: the PC simply reuses the existing LAN path that the
 * Android app already provides for the game server.</p>
 */
public final class LanBridgeConfig {

    /** Default proxy port exposed by the Android app's HttpProxyServer. */
    public static final int DEFAULT_PROXY_PORT = 25580;

    /** Default game relay port exposed by the Android app's TcpRelayEngine. */
    public static final int DEFAULT_GAME_RELAY_PORT = 25565;

    /** Default UDP relay port exposed by the Android app's UdpRelayEngine. */
    public static final int DEFAULT_UDP_RELAY_PORT = 25581;

    /** Discovery path served by the Android proxy for auto configuration. */
    public static final String DISCOVERY_PATH = "/__lanbridge_info";

    /** Filename of the config relative to the game run directory. */
    public static final String CONFIG_RELATIVE_PATH = "config/lanbridge.json";

    private String bridgeHostIp = "";
    private int proxyPort = DEFAULT_PROXY_PORT;
    private int gameRelayPort = DEFAULT_GAME_RELAY_PORT;
    /**
     * The UDP relay port on the Android host. When &gt; 0, the
     * {@code DatagramSocketMixin} routes outbound UDP datagrams for Essential mod
     * P2P traffic (STUN, TURN, QUIC-over-UDP) through the relay. Set to 0 to
     * disable UDP relaying entirely.
     */
    private int udpRelayPort = DEFAULT_UDP_RELAY_PORT;
    /**
     * When true, route the Essential mod's UDP P2P traffic (STUN/TURN/QUIC) through
     * the UDP relay. When false, UDP traffic goes direct (use this if the PC has
     * direct internet and only needs the TCP/HTTPS bridge for auth). Defaults to
     * true so that Essential mod's SPS works through the bridge out of the box.
     */
    private boolean routeEssential = true;
    /**
     * When true, only authentication/session/profile hosts are routed. When false,
     * ALL HTTPS is routed through the bridge &mdash; which is what you want when the
     * PC has no direct internet and needs third-party mod traffic (e.g. the
     * Essential mod&rsquo;s API calls) to also travel over the LAN bridge. Defaults
     * to false so the bridge acts as the PC&rsquo;s sole internet path.
     */
    private boolean authOnly = false;
    /** When true and bridgeHostIp is blank, probe the LAN for a running bridge. */
    private boolean autoDiscover = true;
    /** Milliseconds to wait for a proxied connection before falling back to direct. */
    private int connectTimeoutMs = 4000;
    /** When true, allow falling back to a direct (non-proxied) connection if the proxy is unreachable. */
    private boolean allowFallback = true;

    private static LanBridgeConfig INSTANCE;

    private LanBridgeConfig() {}

    public static synchronized LanBridgeConfig get() {
        if (INSTANCE == null) {
            INSTANCE = new LanBridgeConfig();
            INSTANCE.load();
        }
        return INSTANCE;
    }

    /** Resolve the config file path relative to the current working directory. */
    private static Path configPath() {
        return Paths.get(CONFIG_RELATIVE_PATH);
    }

    /** Load (or create with defaults) the config file. Safe to call repeatedly. */
    public synchronized void load() {
        Path path = configPath();
        if (!Files.exists(path)) {
            save();
            return;
        }
        try {
            String json = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
            fromJson(json.trim());
        } catch (IOException | RuntimeException e) {
            // Corrupt or unreadable: rewrite defaults so the game can still start.
            System.err.println("[LAN Bridge] Could not read config, using defaults: " + e.getMessage());
            save();
        }
    }

    /** Persist the current values back to disk in a stable, human-editable order. */
    public synchronized void save() {
        Path path = configPath();
        try {
            if (path.getParent() != null) {
                Files.createDirectories(path.getParent());
            }
            Files.write(path, toJson().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("[LAN Bridge] Could not write config: " + e.getMessage());
        }
    }

    // ----- accessors -----

    public String getBridgeHostIp() { return bridgeHostIp == null ? "" : bridgeHostIp.trim(); }

    public void setBridgeHostIp(String bridgeHostIp) { this.bridgeHostIp = bridgeHostIp == null ? "" : bridgeHostIp.trim(); }

    public int getProxyPort() { return proxyPort; }

    public void setProxyPort(int proxyPort) {
        if (proxyPort <= 0 || proxyPort > 65535) {
            this.proxyPort = DEFAULT_PROXY_PORT;
        } else {
            this.proxyPort = proxyPort;
        }
    }

    public int getGameRelayPort() { return gameRelayPort; }

    public void setGameRelayPort(int gameRelayPort) {
        if (gameRelayPort <= 0 || gameRelayPort > 65535) {
            this.gameRelayPort = DEFAULT_GAME_RELAY_PORT;
        } else {
            this.gameRelayPort = gameRelayPort;
        }
    }

    public int getUdpRelayPort() { return udpRelayPort; }

    public void setUdpRelayPort(int udpRelayPort) {
        if (udpRelayPort < 0 || udpRelayPort > 65535) {
            this.udpRelayPort = DEFAULT_UDP_RELAY_PORT;
        } else {
            this.udpRelayPort = udpRelayPort;
        }
    }

    public boolean isRouteEssential() { return routeEssential; }

    public void setRouteEssential(boolean routeEssential) { this.routeEssential = routeEssential; }

    public boolean isAuthOnly() { return authOnly; }

    public void setAuthOnly(boolean authOnly) { this.authOnly = authOnly; }

    public boolean isAutoDiscover() { return autoDiscover; }

    public void setAutoDiscover(boolean autoDiscover) { this.autoDiscover = autoDiscover; }

    public int getConnectTimeoutMs() { return connectTimeoutMs; }

    public void setConnectTimeoutMs(int connectTimeoutMs) {
        this.connectTimeoutMs = Math.max(500, connectTimeoutMs);
    }

    public boolean isAllowFallback() { return allowFallback; }

    public void setAllowFallback(boolean allowFallback) { this.allowFallback = allowFallback; }

    /** True when the config has a usable host IP (non-empty and not a placeholder). */
    public boolean hasHost() {
        String h = getBridgeHostIp();
        return !h.isEmpty() && !h.equalsIgnoreCase("0.0.0.0");
    }

    // ----- minimal JSON (no external deps) -----

    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"bridgeHostIp\": ").append(quote(bridgeHostIp)).append(",\n");
        sb.append("  \"proxyPort\": ").append(proxyPort).append(",\n");
        sb.append("  \"gameRelayPort\": ").append(gameRelayPort).append(",\n");
        sb.append("  \"udpRelayPort\": ").append(udpRelayPort).append(",\n");
        sb.append("  \"routeEssential\": ").append(routeEssential).append(",\n");
        sb.append("  \"authOnly\": ").append(authOnly).append(",\n");
        sb.append("  \"autoDiscover\": ").append(autoDiscover).append(",\n");
        sb.append("  \"connectTimeoutMs\": ").append(connectTimeoutMs).append(",\n");
        sb.append("  \"allowFallback\": ").append(allowFallback).append("\n");
        sb.append("}\n");
        return sb.toString();
    }

    private void fromJson(String json) {
        // A deliberately tiny hand-rolled parser: the file is small and flat.
        this.bridgeHostIp = readString(json, "bridgeHostIp", bridgeHostIp);
        this.proxyPort = readInt(json, "proxyPort", proxyPort);
        this.gameRelayPort = readInt(json, "gameRelayPort", gameRelayPort);
        this.udpRelayPort = readInt(json, "udpRelayPort", udpRelayPort);
        this.routeEssential = readBool(json, "routeEssential", routeEssential);
        this.authOnly = readBool(json, "authOnly", authOnly);
        this.autoDiscover = readBool(json, "autoDiscover", autoDiscover);
        this.connectTimeoutMs = readInt(json, "connectTimeoutMs", connectTimeoutMs);
        this.allowFallback = readBool(json, "allowFallback", allowFallback);
    }

    private static String quote(String s) {
        if (s == null) s = "";
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        b.append(String.format("\\u%04x", (int) c));
                    } else {
                        b.append(c);
                    }
            }
        }
        return b.append('"').toString();
    }

    private static String readString(String json, String key, String def) {
        String raw = readRaw(json, key);
        if (raw == null) return def;
        raw = raw.trim();
        if (raw.length() >= 2 && raw.startsWith("\"") && raw.endsWith("\"")) {
            return unescape(raw.substring(1, raw.length() - 1));
        }
        return def;
    }

    private static int readInt(String json, String key, int def) {
        String raw = readRaw(json, key);
        if (raw == null) return def;
        try { return Integer.parseInt(raw.trim()); } catch (NumberFormatException e) { return def; }
    }

    private static boolean readBool(String json, String key, boolean def) {
        String raw = readRaw(json, key);
        if (raw == null) return def;
        String t = raw.trim();
        if (t.equalsIgnoreCase("true")) return true;
        if (t.equalsIgnoreCase("false")) return false;
        return def;
    }

    /** Read the raw value token following "key": (handles nested quotes). */
    private static String readRaw(String json, String key) {
        String needle = "\"" + key + "\"";
        int idx = json.indexOf(needle);
        if (idx < 0) return null;
        int colon = json.indexOf(':', idx + needle.length());
        if (colon < 0) return null;
        int start = colon + 1;
        // skip whitespace
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;
        if (start >= json.length()) return null;
        char first = json.charAt(start);
        if (first == '"') {
            int end = start + 1;
            while (end < json.length()) {
                char c = json.charAt(end);
                if (c == '\\') { end += 2; continue; }
                if (c == '"') { end++; break; }
                end++;
            }
            return json.substring(start, Math.min(end, json.length()));
        } else {
            int end = start;
            while (end < json.length()) {
                char c = json.charAt(end);
                if (c == ',' || c == '}' || c == '\n' || c == '\r') break;
                end++;
            }
            return json.substring(start, end).trim();
        }
    }

    private static String unescape(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case '"': b.append('"'); break;
                    case '\\': b.append('\\'); break;
                    case '/': b.append('/'); break;
                    case 'n': b.append('\n'); break;
                    case 'r': b.append('\r'); break;
                    case 't': b.append('\t'); break;
                    default: b.append(n);
                }
            } else {
                b.append(c);
            }
        }
        return b.toString();
    }

    // Prevent the map import warning; used for ordered documentation in future.
    @SuppressWarnings("unused")
    private static Map<String, Object> emptyOrdered() { return new LinkedHashMap<>(); }
}
