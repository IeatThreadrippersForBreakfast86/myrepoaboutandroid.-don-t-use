package com.ninjatech.lanbridge.mixin;

import com.ninjatech.lanbridge.proxy.LanBridgeProxyInstaller;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.net.ProxySelector;
import java.net.http.HttpClient;

/**
 * Forces every {@link java.net.http.HttpClient} that Minecraft / authlib
 * constructs to use the LAN Bridge proxy when one is active.
 *
 * <p>Although a {@code HttpClient} built with the default builder normally inherits
 * the JVM-default {@link ProxySelector} (which {@link LanBridgeProxyInstaller} has
 * already replaced), some Minecraft versions build their client with an explicit
 * {@code .proxy(ProxySelector.getDefault())} call captured at class-init time, or
 * with {@code ProxySelector.of(...)}. This mixin guarantees that the builder ends up
 * with our selector regardless of how it was constructed, by setting the proxy on
 * the builder <em>before</em> {@code build()} runs.</p>
 *
 * <p>We target the concrete JDK implementation class
 * {@code jdk.internal.net.http.HttpClientBuilderImpl} (which implements
 * {@link HttpClient.Builder}) rather than the interface itself, because the Forge
 * Mixin annotation processor (0.8.5) does not support injectors in interface mixins.
 * The implementation class is a normal class with a {@code build()} method, so a
 * standard HEAD inject works. {@code remap = false} is set because this is a JDK
 * class, not a Minecraft class.</p>
 *
 * <p>If no bridge proxy is active, the mixin does nothing, preserving normal
 * behaviour.</p>
 */
@Mixin(targets = "jdk.internal.net.http.HttpClientBuilderImpl", remap = false)
public abstract class HttpClientBuilderMixin {

    @Inject(method = "build", at = @At("HEAD"))
    private void lanbridge$applyProxy(CallbackInfo ci) {
        if (!LanBridgeProxyInstaller.isInstalled()) {
            return;
        }
        try {
            ProxySelector selector = ProxySelector.getDefault();
            if (selector != null) {
                ((HttpClient.Builder) this).proxy(selector);
            }
        } catch (Throwable t) {
            // Never break the game: if applying the proxy fails, keep going.
            System.err.println("[LAN Bridge] Could not apply proxy to HttpClient.Builder: " + t.getMessage());
        }
    }
}
