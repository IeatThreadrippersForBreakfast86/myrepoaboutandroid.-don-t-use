package com.ninjatech.lanbridge.mixin;

import com.ninjatech.lanbridge.proxy.LanBridgeProxyInstaller;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import java.net.Proxy;

/**
 * THE core fix for the &ldquo;authentication servers are currently
 * unreachable&rdquo; error on Minecraft 1.20.1 (Forge, authlib 4.x).
 *
 * <h2>Why this mixin exists</h2>
 * <p>Authlib&rsquo;s {@code HttpAuthenticationService} stores a single
 * {@link java.net.Proxy} in a {@code private final} field and uses
 * {@code URL.openConnection(thatProxy)} for every auth/session/profile HTTPS
 * request. When you pass an explicit {@code Proxy} to
 * {@code URL.openConnection(Proxy)} the JVM <strong>does not consult
 * {@link java.net.ProxySelector} at all</strong> &mdash; so a JVM-wide default
 * selector has <em>zero effect</em> on Minecraft&rsquo;s auth traffic.</p>
 *
 * <p>{@code net.minecraft.client.Minecraft}&apos;s constructor does:</p>
 * <pre>
 *   this.proxy = gameConfig.user.proxy;          // Proxy.NO_PROXY by default
 *   this.authenticationService = new YggdrasilAuthenticationService(this.proxy);
 *   this.minecraftSessionService = this.authenticationService.createMinecraftSessionService();
 *   this.userApiService = this.createUserApiService(this.authenticationService, gameConfig);
 * </pre>
 * <p>The {@code Proxy} is then baked, {@code final}, into every session/profile
 * service. The only way to redirect auth traffic through the LAN Bridge proxy is
 * to swap the {@code Proxy} <em>before</em> the
 * {@code YggdrasilAuthenticationService} is constructed.</p>
 *
 * <h2>How it works</h2>
 * <p>This mixin uses {@link ModifyArg} to rewrite the {@code Proxy} argument
 * passed to {@code YggdrasilAuthenticationService}&apos;s constructor inside
 * {@code Minecraft.&lt;init&gt;}. When a bridge proxy is active, the original
 * {@code Proxy.NO_PROXY} is replaced with our bridge {@code Proxy}, so the auth
 * service (and every session/profile service it spawns) carries the bridge proxy
 * and auth traffic flows through the Android host&rsquo;s CONNECT tunnel over the
 * LAN.</p>
 *
 * <p>If no bridge proxy is active yet the mixin leaves the original argument
 * untouched and Minecraft behaves as normal. The reflective
 * {@code LanBridgeProxyInstaller.patchAuthServices()} path handles a host
 * configured <em>after</em> launch (via the in-game config screen).</p>
 *
 * <p>Forge 1.20.1 runs on official (Mojang) mappings, so the runtime class name
 * is {@code net.minecraft.client.Minecraft} and the constructor descriptor is
 * {@code (Lnet/minecraft/client/main/GameConfig;)V}. The authlib constructor
 * target is not remapped (authlib ships under its real names), so the literal
 * descriptor matches at runtime.</p>
 */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

    /**
     * Rewrite the {@link Proxy} argument passed to
     * {@code YggdrasilAuthenticationService}&apos;s constructor inside
     * {@code Minecraft}&apos;s constructor. {@code index = 0} selects the first
     * (and only) argument, which is the {@code Proxy}.
     */
    @ModifyArg(
            method = "<init>",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;<init>(Ljava/net/Proxy;)V"
            ),
            index = 0
    )
    private Proxy lanbridge$swapAuthProxy(Proxy original) {
        try {
            Proxy bridge = LanBridgeProxyInstaller.getActiveProxy();
            if (bridge == null) {
                // Last-second install attempt in case the host became known
                // between mod construction and Minecraft construction.
                LanBridgeProxyInstaller.install(null);
                bridge = LanBridgeProxyInstaller.getActiveProxy();
            }
            if (bridge == null) {
                System.out.println("[LAN Bridge] Minecraft init: no bridge proxy active; auth proxy unchanged (direct).");
                return original;
            }
            System.out.println("[LAN Bridge] Minecraft init: routing auth via bridge " + bridge + " (was " + original + ").");
            return bridge;
        } catch (Throwable t) {
            System.err.println("[LAN Bridge] Minecraft init: could not swap auth proxy: " + t);
            return original;
        }
    }
}
