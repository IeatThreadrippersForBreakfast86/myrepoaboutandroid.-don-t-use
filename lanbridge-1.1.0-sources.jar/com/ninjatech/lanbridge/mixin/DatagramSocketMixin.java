package com.ninjatech.lanbridge.mixin;

import com.ninjatech.lanbridge.proxy.LanBridgeProxyInstaller;
import com.ninjatech.lanbridge.proxy.LanBridgeUdpFramer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.lang.reflect.Field;

/**
 * Redirects outbound UDP datagrams through the LAN Bridge UDP relay and restores
 * the real source address on inbound datagrams, so that the Essential mod's
 * custom ICE/QUIC stack (which uses {@link java.net.DatagramSocket} for STUN,
 * TURN, and P2P game data) works through the bridge over the existing LAN &mdash;
 * no new IP, no tethering.
 *
 * <h2>Outbound ({@code send})</h2>
 * <p>For each datagram whose destination should be routed through the relay, we:
 * <ol>
 *   <li>Build a framed buffer: {@code [LanBridge header][original payload]} where
 *       the header encodes the real destination (host + port).</li>
 *   <li>Rewrite the {@link DatagramPacket}'s address to
 *       {@code (relayLanHost, relayUdpPort)} so the raw socket sends it to the
 *       Android relay.</li>
 *   <li>Swap the packet's internal buffer to the framed one (keeping a reference
 *       to the original so we can restore it after the send completes).</li>
 * </ol>
 * The relay strips the header and forwards the payload to the real destination.</p>
 *
 * <h2>Inbound ({@code receive})</h2>
 * <p>After the underlying {@code receive()} returns, we check whether the received
 * data starts with the LanBridge magic byte. If so, we parse the header to recover
 * the real source address, strip the header (shifting the payload to the front of
 * the buffer), and rewrite the packet's address to the real source. This makes the
 * Essential mod's code see packets as if they came directly from the peer.</p>
 *
 * <h2>Reflection on DatagramPacket</h2>
 * <p>{@link DatagramPacket} exposes its address via {@code getAddress()} /
 * {@code setAddress()}, and its buffer via {@code getData()} / {@code setData()}.
 * We use the public API wherever possible and only fall back to reflection for
 * the internal {@code offset} and {@code length} fields (which have no public
 * setter for arbitrary values). The reflection is cached in static fields after
 * the first successful lookup.</p>
 *
 * <p>{@code remap = false} because this targets a JDK class, not a Minecraft class.</p>
 */
@Mixin(targets = "java.net.DatagramSocket", remap = false)
public abstract class DatagramSocketMixin {

    @Shadow
    public abstract void send(DatagramPacket p) throws java.io.IOException;

    @Shadow
    public abstract void receive(DatagramPacket p) throws java.io.IOException;

    // --- Cached reflective fields for DatagramPacket internals ---
    private static volatile Field bufField;
    private static volatile Field offsetField;
    private static volatile Field lengthField;
    private static volatile boolean reflectionInitFailed = false;

    /**
     * Intercept {@code send()}: frame the payload and rewrite the destination to
     * the relay address when the real destination should be routed.
     */
    @Inject(method = "send", at = @At("HEAD"), cancellable = true)
    private void lanbridge$send(DatagramPacket p, CallbackInfo ci) {
        InetSocketAddress relayAddr = LanBridgeProxyInstaller.getUdpRelayAddress();
        if (relayAddr == null) {
            return; // No relay configured; let the original send proceed.
        }
        InetAddress destAddr = p.getAddress();
        int destPort = p.getPort();
        if (destAddr == null || destPort <= 0) {
            return; // Not yet connected; nothing to rewrite.
        }
        InetSocketAddress dest = new InetSocketAddress(destAddr, destPort);

        // Don't route traffic that is already going to the relay (avoid loops).
        if (LanBridgeProxyInstaller.isUdpRelayAddress(destAddr, destPort)) {
            return;
        }
        // Don't route localhost / loopback traffic.
        if (LanBridgeProxyInstaller.isLocalAddress(destAddr)) {
            return;
        }
        // Only route if the destination should be routed through the relay.
        if (!LanBridgeProxyInstaller.shouldRouteUdp(dest)) {
            return;
        }

        try {
            // Build the framed payload.
            byte[] originalData = p.getData();
            int originalOffset = p.getOffset();
            int originalLength = p.getLength();
            byte[] framed = LanBridgeUdpFramer.frame(dest, originalData, originalOffset, originalLength);

            // Save the original buffer reference so we can restore it.
            byte[] savedBuf = originalData;
            int savedOffset = originalOffset;
            int savedLength = originalLength;
            InetAddress savedAddr = destAddr;
            int savedPort = destPort;

            // Rewrite the packet to point at the relay with the framed payload.
            p.setData(framed, 0, framed.length);
            p.setAddress(relayAddr.getAddress());
            p.setPort(relayAddr.getPort());

            try {
                // Perform the actual send to the relay.
                send(p);
            } finally {
                // Restore the packet to its original state so the caller's
                // reference is not corrupted (some callers reuse the same
                // DatagramPacket object for multiple sends).
                p.setData(savedBuf, savedOffset, savedLength);
                p.setAddress(savedAddr);
                p.setPort(savedPort);
            }
            ci.cancel(); // We already sent; skip the original send().
        } catch (Throwable t) {
            // If framing/sending fails, fall through to the original send() so
            // the mod doesn't break. This is the safe fallback.
            System.err.println("[LAN Bridge] UDP send interception failed, falling back to direct: " + t.getMessage());
            // Do NOT cancel; let the original send() run.
        }
    }

    /**
     * Intercept {@code receive()}: after the underlying receive returns, check
     * for a framed header, strip it, and restore the real source address.
     *
     * <p>We inject at TAIL (after the original method body completes) so the
     * real receive has already populated the packet. Then we post-process it.</p>
     */
    @Inject(method = "receive", at = @At("TAIL"))
    private void lanbridge$receive(DatagramPacket p, CallbackInfo ci) {
        if (LanBridgeProxyInstaller.getUdpRelayAddress() == null) {
            return; // No relay configured; nothing to unframe.
        }
        try {
            byte[] data = p.getData();
            int offset = p.getOffset();
            int length = p.getLength();
            if (!LanBridgeUdpFramer.isFramed(data, offset, length)) {
                return; // Not a framed datagram; leave as-is.
            }
            LanBridgeUdpFramer.ParsedHeader parsed = LanBridgeUdpFramer.parse(data, offset, length);
            if (parsed == null) {
                return; // Malformed; leave as-is (best-effort).
            }
            // Shift the payload to the front of the buffer (in place).
            int payloadLen = parsed.payloadLength;
            if (payloadLen <= 0) {
                // Empty payload after header; set length to 0 but fix address.
                setPacketLength(p, 0);
                p.setAddress(parsed.address.getAddress());
                p.setPort(parsed.address.getPort());
                return;
            }
            // Move the payload bytes to the start of the buffer.
            System.arraycopy(data, parsed.payloadOffset, data, offset, payloadLen);
            setPacketLength(p, payloadLen);
            // Restore the real source address.
            p.setAddress(parsed.address.getAddress());
            p.setPort(parsed.address.getPort());
        } catch (Throwable t) {
            System.err.println("[LAN Bridge] UDP receive interception failed: " + t.getMessage());
        }
    }

    /**
     * Set the internal {@code length} field of a {@link DatagramPacket} via
     * reflection (there is no public setter that takes an arbitrary length without
     * also changing the buffer/offset). The reflective fields are looked up once
     * and cached.
     */
    private static void setPacketLength(DatagramPacket p, int len) {
        if (reflectionInitFailed) {
            // Fallback: use setData with the existing buffer + offset + length.
            p.setData(p.getData(), p.getOffset(), len);
            return;
        }
        try {
            if (lengthField == null) {
                initReflection(p);
            }
            if (lengthField != null) {
                lengthField.setInt(p, len);
            } else {
                p.setData(p.getData(), p.getOffset(), len);
            }
        } catch (Throwable t) {
            // Reflection failed; fall back to the public API.
            reflectionInitFailed = true;
            p.setData(p.getData(), p.getOffset(), len);
        }
    }

    /**
     * Look up and cache the private {@code buf}, {@code offset}, and
     * {@code length} fields of {@link DatagramPacket}.
     */
    private static void initReflection(DatagramPacket sample) {
        try {
            Field f;
            // length
            f = DatagramPacket.class.getDeclaredField("length");
            f.setAccessible(true);
            lengthField = f;
            // offset (needed by some JDK versions)
            try {
                f = DatagramPacket.class.getDeclaredField("offset");
                f.setAccessible(true);
                offsetField = f;
            } catch (NoSuchFieldException ignored) {}
            // buf (rarely needed but cached for completeness)
            try {
                f = DatagramPacket.class.getDeclaredField("buf");
                f.setAccessible(true);
                bufField = f;
            } catch (NoSuchFieldException ignored) {}
        } catch (Throwable t) {
            reflectionInitFailed = true;
        }
    }
}
