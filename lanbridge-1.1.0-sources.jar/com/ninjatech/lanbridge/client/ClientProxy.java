package com.ninjatech.lanbridge.client;

import com.ninjatech.lanbridge.LanBridge;
import com.ninjatech.lanbridge.config.LanBridgeConfig;
import com.ninjatech.lanbridge.proxy.LanBridgeDiscovery;
import com.ninjatech.lanbridge.proxy.LanBridgeProxyInstaller;
import com.ninjatech.lanbridge.ui.LanBridgeConfigScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

import java.util.concurrent.TimeUnit;

/**
 * Client-only initialization for the LAN Bridge Forge mod.
 *
 * <p>Installs the JVM-wide HTTP proxy that routes Minecraft's auth / session /
 * profile HTTPS traffic through the Android host device's CONNECT-tunnel proxy over
 * the existing LAN. This is the Forge equivalent of the Fabric
 * {@code LanBridgeClientEntrypoint}.</p>
 *
 * <p>If a host IP is configured in {@code config/lanbridge.json} it is used
 * immediately; otherwise, when auto-discovery is enabled, the local subnet is probed
 * for the Android app's {@code /__lanbridge_info} endpoint. Either way no new IP is
 * added \u2014 the PC reuses the LAN path that is already there.</p>
 */
@OnlyIn(Dist.CLIENT)
public final class ClientProxy {

    private ClientProxy() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientProxy::onClientSetup);
    }

    private static void onClientSetup(final FMLClientSetupEvent event) {
        LanBridgeConfig cfg = LanBridgeConfig.get();

        // Register our config screen so the Mods list "Config" button opens it.
        // This is the forum-verified Forge 1.20.x pattern: registerExtensionPoint
        // on the mod loading context (NOT RegisterConfigScreenEvent, which is not
        // available in Forge 47.x for 1.20.1).
        ModLoadingContext.get().registerExtensionPoint(
                ConfigScreenHandler.ConfigScreenFactory.class,
                () -> new ConfigScreenHandler.ConfigScreenFactory(
                        (mc, parentScreen) -> new LanBridgeConfigScreen(parentScreen)));

        if (cfg.hasHost()) {
            LanBridgeProxyInstaller.install(null);
            LanBridge.LOGGER.info("[LAN Bridge] Proxy installed from config \u2192 {}:{}",
                    cfg.getBridgeHostIp(), cfg.getProxyPort());
            return;
        }

        if (cfg.isAutoDiscover()) {
            LanBridge.LOGGER.info("[LAN Bridge] No host configured; starting LAN discovery...");
            event.enqueueWork(() -> {
                // Run discovery on a background thread; enqueueWork gives us a safe
                // point but discovery is network-bound so we keep it off-thread.
            });
            Thread t = new Thread(() -> {
                try {
                    LanBridgeDiscovery.BridgeInfo info = LanBridgeDiscovery.discover(10, TimeUnit.SECONDS);
                    if (info != null) {
                        cfg.setBridgeHostIp(info.lanHost);
                        cfg.setProxyPort(info.proxyPort);
                        cfg.setGameRelayPort(info.gameRelayPort);
                        cfg.setUdpRelayPort(info.udpRelayPort);
                        cfg.save();
                        LanBridgeProxyInstaller.install(null);
                        LanBridge.LOGGER.info("[LAN Bridge] Discovered bridge \u2192 {}:{} (game relay {}, UDP relay {})",
                                info.lanHost, info.proxyPort, info.gameRelayPort,
                                info.udpRelayPort > 0 ? info.udpRelayPort : "disabled");
                    } else {
                        LanBridge.LOGGER.warn("[LAN Bridge] No bridge found on the LAN. Set bridgeHostIp in config/lanbridge.json.");
                    }
                } catch (Exception e) {
                    LanBridge.LOGGER.error("[LAN Bridge] Discovery failed: {}", e.getMessage());
                }
            }, "lanbridge-discovery");
            t.setDaemon(true);
            t.start();
        } else {
            LanBridge.LOGGER.warn("[LAN Bridge] No host configured and auto-discovery disabled. Set bridgeHostIp in config/lanbridge.json.");
        }
    }
}
