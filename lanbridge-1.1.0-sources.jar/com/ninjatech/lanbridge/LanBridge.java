package com.ninjatech.lanbridge;

import com.ninjatech.lanbridge.client.ClientProxy;
import com.ninjatech.lanbridge.config.LanBridgeConfig;
import com.ninjatech.lanbridge.proxy.LanBridgeProxyInstaller;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Main Forge mod class for the LAN Bridge (Forge 1.20.1).
 *
 * <p>The mod's job is simple: install a JVM-wide HTTP proxy pointing at the Android
 * host device's CONNECT-tunnel proxy so that the Minecraft client's authentication,
 * session and profile HTTPS requests travel over the existing LAN \u2014 no new IP, no
 * tethering.</p>
 *
 * <p>The actual proxy installation runs on the client side only (see
 * {@link ClientProxy}). On the dedicated server this mod is effectively a no-op.</p>
 */
@Mod(LanBridge.MODID)
public class LanBridge {

    public static final String MODID = "lanbridge";
    public static final Logger LOGGER = LogManager.getLogger(MODID);

    private static LanBridge INSTANCE;

    public LanBridge() {
        INSTANCE = this;
        // Eagerly load / create the config file.
        LanBridgeConfig cfg = LanBridgeConfig.get();

        // Install the mutable proxy selector IMMEDIATELY — before Minecraft
        // builds its cached HttpClient. This is the key timing fix: if we wait
        // until FMLClientSetupEvent (or the user clicking Apply in the config
        // screen), the already-built HttpClient will never see our selector and
        // auth traffic goes direct ("authentication servers are currently
        // unreachable"). The early selector routes direct until a host is set.
        LanBridgeProxyInstaller.installEarly();
        if (cfg.hasHost()) {
            LanBridgeProxyInstaller.install(null);
            LOGGER.info("[LAN Bridge] Proxy installed from config -> {}:{}", cfg.getBridgeHostIp(), cfg.getProxyPort());
        }

        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::commonSetup);

        // Register the client-side proxy (safe for dedicated server via DistExecutor).
        DistExecutor.unsafeRunWhenOn(net.minecraftforge.api.distmarker.Dist.CLIENT,
                () -> () -> ClientProxy.init(modBus));

        // Register ourselves for server / other game events.
        MinecraftForge.EVENT_BUS.register(this);

        LOGGER.info("LAN Bridge mod constructing.");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("LAN Bridge common setup complete. Configure via config/lanbridge.json.");
    }

    public static LanBridge getInstance() {
        return INSTANCE;
    }
}
